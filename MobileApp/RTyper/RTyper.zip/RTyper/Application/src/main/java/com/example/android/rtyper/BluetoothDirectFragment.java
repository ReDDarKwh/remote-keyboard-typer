package com.example.android.rtyper;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.common.logger.Log;

/**
 * Created by ReDDarK on 17-Apr-2018.
 */

public class BluetoothDirectFragment extends BluetoothBase{


    public ListView mConversationView;
    public EditText mOutEditText;
    public Button mSendButton;
    public ArrayAdapter<String> mConversationArrayAdapter;
    /**
     * The action listener for the EditText widget, to listen for the return key
     */




    @Override
    public void sendMessage(String message, Activity activity) {
        // Check that we're actually connected before trying anything
        if (mCommService.getState() != BluetoothService.STATE_CONNECTED) {
            Toast.makeText(activity, R.string.not_connected, Toast.LENGTH_SHORT).show();
            return;
        }

        // Check that there's actually something to send
        if (message.length() > 0) {
            // Get the message bytes and tell the BluetoothService to write
            byte[] send = message.getBytes();
            mCommService.write(send);

            // Reset out string buffer to zero and clear the edit text field
            mOutStringBuffer.setLength(0);
            mOutEditText.setText(mOutStringBuffer);
        }
    }

    public void setupComm(final View view, final Activity activity) {


        // Initialize the array adapter for the conversation thread
        mConversationArrayAdapter = new ArrayAdapter<String>(activity, R.layout.message);

        mConversationView.setAdapter(mConversationArrayAdapter);

        // Initialize the compose field with a listener for the return key
        mOutEditText.setOnEditorActionListener((TextView tView, int actionId, KeyEvent event) -> {
            if (actionId == EditorInfo.IME_NULL
                    && event.getAction() == KeyEvent.ACTION_DOWN) {
                String message = tView.getText().toString();
                sendMessage(message, activity);
            }
            return true;
        });

        // Initialize the send button with a listener that for click events
        mSendButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Send a message using content of the edit text widget

                if (null != view) {
                    TextView textView = (TextView) view.findViewById(R.id.edit_text_out);
                    String message = textView.getText().toString();
                    sendMessage(message, activity);
                }
            }
        });

        // Initialize the BluetoothService to perform bluetooth connections
        mCommService = BluetoothService.getInstance();

        mCommService.start();


        // Initialize the buffer for outgoing messages
        mOutStringBuffer = new StringBuffer("");



    }


    public BluetoothDirectFragment() {
        super();
    }

    @Override
    public void onViewCreated(View view) {
        mConversationView = (ListView) view.findViewById(R.id.in);
        mOutEditText = (EditText) view.findViewById(R.id.edit_text_out);
        mSendButton = (Button) view.findViewById(R.id.button_send);
    }
}
