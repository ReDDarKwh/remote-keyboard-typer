package com.android.graphics;

/**
 * Created by ReDDarK on 17-Apr-2018.
 */

public interface IMoveCallback {

    void callback(float x, float y);
}
