package com.android.graphics;

import android.graphics.Path;

import java.util.ArrayList;

/**
 * Created by ReDDarK on 17-Apr-2018.
 */

public interface INewPathCallback {

    void callback(boolean down);
}
